export const vehicleTypes = [
  'Turismo',
  'SUV/4x4',
  'Furgoneta/Comercial',
  'Deportivo',
  'Monovolumen'
];
