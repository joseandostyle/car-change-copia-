export default {
  primary: '#FFD700',
  secondary: '#3E3E3E',
  background: '#FFF',
  accent: '#FF8C00',
  text: '#111'
};
