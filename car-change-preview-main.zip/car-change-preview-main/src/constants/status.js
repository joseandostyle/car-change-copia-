export const exchangeStatus = {
  pending: 'Pendiente',
  accepted: 'Aceptado',
  rejected: 'Rechazado',
  completed: 'Completado',
  disputed: 'En disputa'
};
