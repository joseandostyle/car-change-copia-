# CarChange Preview

Este repositorio contiene el **preview del MVP** de CarChange para previsualizar en Lovable.dev.

## Cómo usar

1. Conecta este repo a Lovable.dev  
2. Escanea el QR con Expo Go o usa el enlace web  
3. Prueba el chat interno, el flujo de onboarding y la navegación básica

---

## Funcionalidades incluidas hasta ahora

- Onboarding completo con 4 pantallas
- Chat interno entre usuarios
- Inicio de solicitud de intercambio
- Sistema de reputación en desarrollo
- Contrato legal previo al intercambio
- Garantía Recíproca CarChange™
